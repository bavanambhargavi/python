class land__animal:
      def printing(self):
          print("this animal lives on land")


class water__animal:
      def display(self):
          print("this animal lives on water")

class frog(land__animal, water__animal):
           pass


f1 = frog()
f1.printing()
f1.display()





class x:
    def display(self):
        print("method belongs to class x")

class y(x):
    def display(self):
        print("this method is belongs to y")

e1 = y()
e1.display()

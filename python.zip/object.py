def display(name):
    print("hello", name)
    return

display("abhi")
display("ram")
num = int(input("enter the number of rows:"))
for i in range(0, num):
    for j in range(0, num-i-1):
        print("*", end=" ")
    print()
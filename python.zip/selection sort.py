list1 = [12, 34, 56, 5]
list2 = [23, 22, 1, 3 ]
print("unsorted list", list1)
for i in range(len(list1)):
    min_val = min(list[1])
for j in range(len(list2)):
    max_val = max(list[2])
if list1 == list2:
    print(list[1])
    print(list[2])

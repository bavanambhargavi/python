list_1 =[1 ,2, 3, 4]
list_2 =[4, 5, 6, 7]
list_3 =[6, 7 ,8 ,9]
for idx, item in enumerate(list_1):
         list_1.filter (item)
for idx, item in  enumerate(list_2):
         list_2.reduce (item)
for idx , item in  enumerate(list_3):
          list_3. remove (item)
print(list_1)
print(list_2)
print(list_3)


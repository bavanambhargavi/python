list1 =[100, 121, 321]
list2 =[212 , 90, 32]
for x in range (1):
      print(" list1 palindrome number")
for y in range(1):
      print("list2 palindrome number or not")



print(list1)
print(list2)
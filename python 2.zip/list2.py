# temperature display using list
daily_temps = [23, 44, 55, 66]
dayname = input("enter sun , mon, tue, wed, thu:")
if dayname == 'sun':
    dayname == 'sunday'
    temp = daily_temps[0]

elif dayname == 'mon':
    dayname == 'monday'
    temp = daily_temps[1]
elif dayname == 'tue':
    dayname == 'tuesday'
    temp = daily_temps[2]
elif  dayname =='wed' :
    dayname == 'wednesday'
    temp = daily_temps[3]
elif dayname == 'thu':
    dayname =='thursday'
    temp = daily_temps[4]

else:
    print("wrong input")
print("the temperature for:", dayname, "was", temp, "degrees")
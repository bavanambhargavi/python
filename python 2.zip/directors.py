# temperature display program using dictionaries
daily_temps = {'sun': 54, 'mon' :66, 'tue' :44, 'wed':55}
dayname = {'sun': 'sunday', 'mon': 'monday', 'tue': 'tuesday', 'wed': 'wednesday'}
day = input("enter 'sun', 'mon', 'tue', 'wed':")
print ("the temperature for", dayname[day], "was", daily_temps[day], "degree")
